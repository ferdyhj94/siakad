<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DaftarNilai extends Model
{
    protected $table = 'daftar_nilai';
}
